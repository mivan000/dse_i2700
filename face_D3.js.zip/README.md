Demonstrates fundamental DOM manipulation using D3.js by making a smiley face whose eyebrows move.

<iframe width="560" height="315" src="https://www.youtube.com/embed/-RQWC4I2I1s?rel=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>